# チーム日報サイト

## 日報の書き方(コーチ)
1. GitHubのこのリポジトリで `reports` フォルダを開く
2. 「Add file」→「Create new file」
3. ファイル名を `2026-10-01.md` の形式にする(日付.md)
4. 1行目に `# タイトル` を書き、本文を書いて「Commit changes」
5. 1〜2分後にサイトが更新されます(スマホのブラウザからでもOK)

## 最初の設定(1回だけ)
1. リポジトリを **Public** で作成し、このフォルダの中身をアップロード
2. Settings → Pages → Source を **GitHub Actions** にする
3. Settings → General → Features → **Discussions** にチェック
4. https://github.com/apps/giscus を開き、このリポジトリにインストール
5. https://giscus.app でリポジトリ名を入力し、
   カテゴリは「Announcements」を選ぶ(ページ下部に `data-repo-id` と `data-category-id` が表示される)
6. `build.py` 上部の `GISCUS = {...}` に、その4つの値を貼り付ける
7. `main` ブランチにpush → Actionsタブで公開の進行を確認

## 注意
- 公開サイトなので、選手のフルネーム・顔写真・連絡先などは書かない
- コメントするには選手がGitHubアカウントを持っている必要があります
- 手元で確認: `pip install -r requirements.txt && python build.py` → `site/index.html` を開く
