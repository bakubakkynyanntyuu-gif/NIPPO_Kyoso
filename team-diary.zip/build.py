"""reports/*.md から site/ フォルダに日報サイトを生成するスクリプト。"""
import html
import re
import shutil
from pathlib import Path

import markdown

# ====== ここを自分のチームに合わせて書き換える ======
SITE_TITLE = "チーム日報"
SITE_DESC = "コーチからの毎日の連絡"

# giscus の設定値は https://giscus.app で取得(README参照)
GISCUS = {
    "repo": "あなたのユーザー名/リポジトリ名",
    "repo_id": "R_xxxxxxxx",
    "category": "Announcements",
    "category_id": "DIC_xxxxxxxx",
}
# ==================================================

ROOT = Path(__file__).parent
REPORTS = ROOT / "reports"
OUT = ROOT / "site"

CSS = """
:root{--bg:#f7f5f0;--ink:#1c2733;--sub:#5d6873;--line:#d9d5ca;--accent:#e0a800;--link:#0f5c8a}
@media (prefers-color-scheme:dark){:root{--bg:#171c22;--ink:#eceae4;--sub:#a1a9b1;--line:#333b44;--accent:#f0bc1c;--link:#6fb6e0}}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font-family:"Hiragino Sans","Noto Sans JP","Yu Gothic",sans-serif;line-height:1.85}
.wrap{max-width:42rem;margin:0 auto;padding:1.5rem 1.25rem 4rem}
header.site{border-left:.4rem solid var(--accent);padding-left:.9rem;margin-bottom:2rem}
header.site a{color:var(--ink);text-decoration:none}
header.site h1{margin:0;font-size:1.5rem}
header.site p{margin:.2rem 0 0;color:var(--sub);font-size:.9rem}
a{color:var(--link)}
a:focus-visible{outline:3px solid var(--accent);outline-offset:2px}
ul.list{list-style:none;margin:0;padding:0}
ul.list li{border-bottom:1px solid var(--line)}
ul.list a{display:flex;gap:1rem;padding:.9rem 0;text-decoration:none;color:var(--ink)}
ul.list time{color:var(--sub);min-width:6.5rem;font-variant-numeric:tabular-nums}
ul.list a:hover .t{text-decoration:underline}
article h1{font-size:1.5rem;line-height:1.4;margin:.2rem 0 1rem}
article h2{font-size:1.15rem;margin:2rem 0 .4rem}
article img{max-width:100%;height:auto}
.date{color:var(--sub);font-size:.9rem}
.nav{display:flex;justify-content:space-between;gap:1rem;margin:2.5rem 0 1rem;font-size:.95rem}
h2.c{font-size:1.1rem;margin:2.5rem 0 1rem;padding-top:1.5rem;border-top:1px solid var(--line)}
"""

PAGE = """<!doctype html>
<html lang="ja"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>{title}</title>
<style>{css}</style>
</head><body><div class="wrap">
<header class="site"><a href="{root}index.html"><h1>{site}</h1></a><p>{desc}</p></header>
{body}
</div></body></html>"""

GISCUS_TAG = """<h2 class="c">コメント</h2>
<script src="https://giscus.app/client.js"
  data-repo="{repo}" data-repo-id="{repo_id}"
  data-category="{category}" data-category-id="{category_id}"
  data-mapping="pathname" data-strict="0" data-reactions-enabled="1"
  data-emit-metadata="0" data-input-position="top" data-theme="preferred_color_scheme"
  data-lang="ja" crossorigin="anonymous" async></script>"""


def title_of(text: str, fallback: str) -> str:
    m = re.search(r"^#\s+(.+)$", text, re.M)
    return m.group(1).strip() if m else fallback


def render(title, body, root=""):
    return PAGE.format(title=html.escape(title), css=CSS, root=root,
                       site=html.escape(SITE_TITLE), desc=html.escape(SITE_DESC), body=body)


def main():
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir()

    files = sorted(REPORTS.glob("*.md"), reverse=True)  # 新しい順
    entries = []
    for f in files:
        text = f.read_text(encoding="utf-8")
        entries.append({"slug": f.stem, "title": title_of(text, f.stem), "text": text})

    for i, e in enumerate(entries):
        body_html = markdown.markdown(e["text"], extensions=["extra", "sane_lists", "nl2br"])
        newer = entries[i - 1] if i > 0 else None
        older = entries[i + 1] if i + 1 < len(entries) else None
        nav = '<nav class="nav"><span>{}</span><span>{}</span></nav>'.format(
            f'<a href="{older["slug"]}.html">前の日報</a>' if older else "",
            f'<a href="{newer["slug"]}.html">次の日報</a>' if newer else "")
        body = (f'<article><div class="date">{e["slug"]}</div>{body_html}</article>'
                f'{nav}{GISCUS_TAG.format(**GISCUS)}')
        (OUT / f'{e["slug"]}.html').write_text(render(e["title"], body), encoding="utf-8")

    items = "".join(
        f'<li><a href="{e["slug"]}.html"><time>{e["slug"]}</time>'
        f'<span class="t">{html.escape(e["title"])}</span></a></li>' for e in entries)
    (OUT / "index.html").write_text(
        render(SITE_TITLE, f'<ul class="list">{items}</ul>' if items else "<p>まだ日報がありません。</p>"),
        encoding="utf-8")
    (OUT / ".nojekyll").write_text("")
    print(f"{len(entries)} 件の日報を site/ に出力しました")


if __name__ == "__main__":
    main()
